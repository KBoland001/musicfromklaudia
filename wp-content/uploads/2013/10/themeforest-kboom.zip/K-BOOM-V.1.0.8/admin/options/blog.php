<?php
    $options[] = array( "name" => "Blog",
    					"sicon" => "blog.png",
						"type" => "heading");

	$options[] = array( "name" => "Display Author Box",
						"desc" => "Show Author box on the Blog Post page.",
						"id" => $shortname."_authorbox",
						"std" => "1",
						"type" => "checkbox");
?>