<?php
    $options[] = array( "name" => "Events",
    					"sicon" => "events.png",
						"type" => "heading");

    $options[] = array( "name" => "Events Item per Page",
                        "desc" => "Set the number of items that appear on the Event page.",
                        "id" => $shortname."_eventitemsperpage",
                        "std" => "6",
                        "type" => "text");
?>