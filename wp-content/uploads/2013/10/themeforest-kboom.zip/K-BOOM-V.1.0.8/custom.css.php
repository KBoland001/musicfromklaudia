<style type="text/css" media="all">

    <?php echo of_get_option('sc_css_code');?>

</style>